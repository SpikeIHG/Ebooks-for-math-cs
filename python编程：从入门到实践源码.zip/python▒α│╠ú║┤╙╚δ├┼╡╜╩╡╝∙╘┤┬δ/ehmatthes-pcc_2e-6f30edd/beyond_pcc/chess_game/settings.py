class Settings:

    def __init__(self):
        self.screen_width, self.screen_height = 800, 300
        self.bg_color = (225, 225, 225)