age = 23
message = "Happy " + str(age) + "rd Birthday!"

print(message)
